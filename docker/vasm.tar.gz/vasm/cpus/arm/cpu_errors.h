  "instruction not supported on selected architecture",ERROR,
  "trailing garbage in operand",WARNING,
  "label from current section required",ERROR,
  "branch offset (%ld) is out of range",ERROR,
  "PC-relative load/store (offset %ld) out of range",ERROR,
  "cannot make rotated immediate from PC-relative offset (0x%lx)",ERROR,/*05*/
  "constant integer expression required",ERROR,
  "constant (0x%lx) not suitable for 8-bit rotated immediate",ERROR,
  "branch to an unaligned address (offset %ld)",ERROR,
  "not a valid ARM register",ERROR,
  "PC (r15) not allowed in this mode",ERROR,                            /*10*/
  "PC (r15) not allowed for offset register Rm",ERROR,
  "PC (r15) not allowed with write-back",ERROR,
  "register r%ld was used multiple times",ERROR,
  "illegal immediate shift count (%ld)",ERROR,
  "not a valid shift register",ERROR,                                   /*15*/
  "24-bit unsigned immediate expected",ERROR,
  "data size %d not supported",ERROR,
  "illegal addressing mode: %s",ERROR,
  "signed/halfword ldr/str doesn't support shifts",ERROR,
  "%d-bit immediate offset out of range (%ld)",ERROR,                   /*20*/
  "post-indexed addressing mode expected",ERROR,
  "operation not allowed on external symbols",ERROR,
  "ldc/stc offset has to be a multiple of 4",ERROR,
  "illegal coprocessor operation mode or type: %ld\n",ERROR,
  "%d-bit unsigned immediate offset out of range (%ld)",ERROR,          /*25*/
  "offset has to be a multiple of %d",ERROR,
  "instruction at unaligned address",ERROR,
  "TSTP/TEQP/CMNP/CMPP deprecated on 32-bit architectures",WARNING,
  "rotate constant must be an even number between 0 and 30: %ld",ERROR,
  "%d-bit unsigned constant required: %ld",ERROR,                       /*30*/
